# Flowpost Studio deploy package

Dominio objetivo:

https://app.touch.com.co

## Subir a cPanel

1. Sube esta carpeta completa como app Node.js, no solo HTML estatico.
2. Startup file: server.js
3. Ejecuta npm install si cPanel lo solicita.
4. Configura variables desde .env.production.example.
5. Usa HOST=0.0.0.0 y APP_PUBLIC_URL=https://app.touch.com.co.

## Verificacion

Cuando este online, abre:

https://app.touch.com.co/api/health
https://app.touch.com.co/api/diagnostics
https://app.touch.com.co/api/production-readiness

## Seguridad

No subas .env con secretos a GitHub.
No guardes tokens reales en frontend.
Rota cualquier contraseña de cPanel compartida por canales no seguros.
